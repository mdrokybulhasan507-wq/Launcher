#!/bin/bash
set -e

echo ">> Installing Android command-line SDK tools..."
export ANDROID_HOME=$HOME/android-sdk
mkdir -p $ANDROID_HOME/cmdline-tools

cd /tmp
curl -o cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip -q cmdline-tools.zip -d $ANDROID_HOME/cmdline-tools
mv $ANDROID_HOME/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest

export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

echo ">> Accepting licenses..."
yes | sdkmanager --licenses > /dev/null || true

echo ">> Installing platform 34, build-tools, platform-tools..."
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" > /dev/null

echo ">> Installing Gradle via SDKMAN..."
curl -s "https://get.sdkman.io" | bash
source "$HOME/.sdkman/bin/sdkman-init.sh"
sdk install gradle 8.7 < /dev/null

# Persist env vars for future terminal sessions in this Codespace
echo "export ANDROID_HOME=$ANDROID_HOME" >> ~/.bashrc
echo "export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools" >> ~/.bashrc
echo "source \$HOME/.sdkman/bin/sdkman-init.sh" >> ~/.bashrc

echo ">> Setup complete! Run: gradle assembleDebug"
