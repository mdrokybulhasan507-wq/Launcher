package com.roky.mylauncher

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity acts as the HOME screen.
 * It shows NO installed apps by default - only a clock and a
 * floating dock (macOS style) containing apps the user manually pins.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var dockIconsHolder: LinearLayout
    private lateinit var packageManager2: PackageManager
    private lateinit var prefs: android.content.SharedPreferences

    companion object {
        private const val PREFS_NAME = "launcher_prefs"
        private const val KEY_PINNED_APPS = "pinned_apps"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        packageManager2 = packageManager
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        dockIconsHolder = findViewById(R.id.dockIconsHolder)
        val addAppButton: ImageView = findViewById(R.id.addAppButton)

        addAppButton.setOnClickListener {
            showAppPickerDialog()
        }

        loadPinnedApps()
    }

    /** Reload dock whenever we come back to home (in case pins changed) */
    override fun onResume() {
        super.onResume()
        loadPinnedApps()
    }

    /** Reads saved package names from SharedPreferences and rebuilds dock icons */
    private fun loadPinnedApps() {
        dockIconsHolder.removeAllViews()
        val pinned = getPinnedPackages()
        for (packageName in pinned) {
            try {
                val appInfo = packageManager2.getApplicationInfo(packageName, 0)
                addDockIcon(appInfo)
            } catch (e: PackageManager.NameNotFoundException) {
                // App was uninstalled - clean it up from prefs
                removePinnedPackage(packageName)
            }
        }
    }

    private fun getPinnedPackages(): MutableList<String> {
        val saved = prefs.getString(KEY_PINNED_APPS, "") ?: ""
        return if (saved.isEmpty()) mutableListOf()
        else saved.split(",").toMutableList()
    }

    private fun savePinnedPackages(list: List<String>) {
        prefs.edit().putString(KEY_PINNED_APPS, list.joinToString(",")).apply()
    }

    private fun addPinnedPackage(packageName: String) {
        val list = getPinnedPackages()
        if (!list.contains(packageName)) {
            list.add(packageName)
            savePinnedPackages(list)
        }
    }

    private fun removePinnedPackage(packageName: String) {
        val list = getPinnedPackages()
        list.remove(packageName)
        savePinnedPackages(list)
    }

    /** Creates one circular icon view in the dock for a given app */
    private fun addDockIcon(appInfo: ApplicationInfo) {
        val icon: Drawable = appInfo.loadIcon(packageManager2)
        val packageName = appInfo.packageName

        val iconView = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(56.dp(), 56.dp()).apply {
                marginEnd = 8.dp()
            }
            setImageDrawable(icon)
            setPadding(6.dp(), 6.dp(), 6.dp(), 6.dp())
            background = androidx.core.content.ContextCompat.getDrawable(
                this@MainActivity, R.drawable.dock_icon_bg
            )

            setOnClickListener {
                launchApp(packageName)
            }
            setOnLongClickListener {
                confirmRemoveFromDock(packageName)
                true
            }
        }
        dockIconsHolder.addView(iconView)
    }

    private fun launchApp(packageName: String) {
        val launchIntent = packageManager2.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "App khola gelo na", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmRemoveFromDock(packageName: String) {
        val appName = try {
            packageManager2.getApplicationLabel(
                packageManager2.getApplicationInfo(packageName, 0)
            ).toString()
        } catch (e: Exception) {
            packageName
        }

        AlertDialog.Builder(this)
            .setTitle("Dock theke remove korbe?")
            .setMessage("$appName ke dock theke sorate chao?")
            .setPositiveButton("Remove") { _, _ ->
                removePinnedPackage(packageName)
                loadPinnedApps()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Shows a scrollable list of ALL installed apps so user can pick ones to pin */
    private fun showAppPickerDialog() {
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolvedApps = packageManager2.queryIntentActivities(mainIntent, 0)
            .sortedBy { it.loadLabel(packageManager2).toString().lowercase() }

        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val listView = android.widget.ListView(this)
        val adapter = AppPickerAdapter(this, resolvedApps, packageManager2)
        listView.adapter = adapter

        val dialog = AlertDialog.Builder(this)
            .setTitle("App select koro dock e add korte")
            .setView(listView)
            .setNegativeButton("Cancel", null)
            .create()

        listView.setOnItemClickListener { _, _, position, _ ->
            val resolveInfo = resolvedApps[position]
            val packageName = resolveInfo.activityInfo.packageName
            addPinnedPackage(packageName)
            loadPinnedApps()
            dialog.dismiss()
        }

        dialog.show()
    }

    /** Simple px-from-dp helper */
    private fun Int.dp(): Int {
        val density = resources.displayMetrics.density
        return (this * density).toInt()
    }

    // Disable back button - launcher should not "go back" to anything
    override fun onBackPressed() {
        // Intentionally does nothing
    }
}

/**
 * Adapter that shows every installed launchable app in the picker dialog.
 * This list is ONLY shown inside the picker - never on the home screen itself.
 */
class AppPickerAdapter(
    private val context: android.content.Context,
    private val apps: List<android.content.pm.ResolveInfo>,
    private val pm: PackageManager
) : BaseAdapter() {

    override fun getCount(): Int = apps.size
    override fun getItem(position: Int): Any = apps[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_app_picker, parent, false)

        val resolveInfo = apps[position]
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val name: TextView = view.findViewById(R.id.appName)

        icon.setImageDrawable(resolveInfo.loadIcon(pm))
        name.text = resolveInfo.loadLabel(pm)

        return view
    }
}
